import React from 'react';
import ReactDOM from 'react-dom';
import Reservation from './components/Reservation.jsx';

ReactDOM.render(<Reservation />, document.getElementById('reservation'));
